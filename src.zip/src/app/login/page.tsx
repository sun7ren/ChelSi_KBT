"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); // Reset error message

    const { error } = await supabase.auth.signInWithPassword({
      email: email,
      password: password,
    });

    if (error) {
      setError(error.message);
    } else {
      router.push("/logged_in"); // Redirect to the logged-in dashboard
    }
  };

  return (
    <div className="font-sans grid grid-rows-[auto_1fr_auto] min-h-screen bg-white">
      {/* HEADER */}
      <header className="row-start-1 w-full flex flex-row items-center gap-4 p-6 bg-white shadow-sm">
        <Image src="/logo.png" alt="ChelSi logo" width={100} height={30} />
        <div className="flex flex-col">
          <h1 className="text-4xl sm:text-4xl font-bold text-blue-800">
            ChelSi
          </h1>
          <p className="mt-1 text-lg text-blue-600 italic">
            Your Lab, Anytime, Anywhere.
          </p>
        </div>
      </header>

      {/* MAIN */}
      <main className="row-start-2 flex items-center justify-center px-6 py-10">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-2xl border border-blue-200 shadow-lg p-8 space-y-6">
            <div className="text-center">
              <h2 className="font-bold text-3xl text-blue-900">
                Welcome Back!
              </h2>
              <p className="text-gray-600 mt-2">
                Enter your details to access your account.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              {error && (
                  <div className="p-3 bg-red-100 text-red-700 rounded-lg text-center text-sm">
                    {error}
                  </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700 font-semibold">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="password"
                  className="text-gray-700 font-semibold"
                >
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-800 text-white font-bold py-3 rounded-lg hover:bg-blue-900 transition-colors"
              >
                Login
              </Button>
            </form>

            <p className="text-center text-sm text-gray-600">
              Don't have an account yet?{" "}
              <Link
                href="/signup"
                className="font-semibold text-blue-600 hover:underline"
              >
                Register
              </Link>
            </p>
          </div>
        </div>
      </main>

      {/* FOOTER */}
      <footer className="row-start-3 flex justify-center items-center bg-blue-800 text-white p-4 mt-8 shadow-inner">
        Informatics Engineering × Chemical Engineering 2025
      </footer>
    </div>
  );
}
