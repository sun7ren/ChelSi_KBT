"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/lib/supabaseClient";

export default function SignupPage() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  const [isError, setIsError] = useState(false);
  const router = useRouter();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsError(false);
    setMessage("");

    if (password !== confirmPassword) {
      setIsError(true);
      setMessage("Passwords do not match.");
      return;
    }

    const { error } = await supabase.auth.signUp({
      email: email,
      password: password,
      options: {
        data: {
          full_name: fullName,
        },
      },
    });

    if (error) {
      setIsError(true);
      setMessage(error.message);
    } else {
      setIsError(false);
      setMessage("Success! Please check your email to verify your account.");
      // Optional: redirect after a delay
      setTimeout(() => router.push("/login"), 3000);
    }
  };

  return (
    <div className="font-sans grid grid-rows-[auto_1fr_auto] min-h-screen bg-white">
      {/* HEADER */}
      <header className="row-start-1 w-full flex flex-row items-center gap-4 p-6 bg-white shadow-sm">
        <Image src="/logo.png" alt="ChelSi logo" width={100} height={30} />
        <div className="flex flex-col">
          <h1 className="text-4xl sm:text-4xl font-bold text-blue-800">
            ChelSi
          </h1>
          <p className="mt-1 text-lg text-blue-600 italic">
            Your Lab, Anytime, Anywhere.
          </p>
        </div>
      </header>

      {/* MAIN */}
      <main className="row-start-2 flex items-center justify-center px-6 py-10">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-2xl border border-blue-200 shadow-lg p-8 space-y-6">
            <div className="text-center">
              <h2 className="font-bold text-3xl text-blue-900">
                Create an Account
              </h2>
              <p className="text-gray-600 mt-2">
                Enter your details to get started.
              </p>
            </div>

            <form onSubmit={handleSignup} className="space-y-4">
              {message && (
                <div
                  className={`p-3 rounded-lg text-center text-sm ${
                    isError
                      ? "bg-red-100 text-red-700"
                      : "bg-green-100 text-green-700"
                  }`}
                >
                  {message}
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="full-name" className="text-gray-700 font-semibold">
                  Full Name
                </Label>
                <Input
                  id="full-name"
                  type="text"
                  placeholder="e.g. Marie Curie"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
               <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700 font-semibold">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-700 font-semibold">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirm-password" className="text-gray-700 font-semibold">
                  Confirm Password
                </Label>
                <Input
                  id="confirm-password"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-800 text-white font-bold py-3 rounded-lg hover:bg-blue-900 transition-colors"
              >
                Sign Up
              </Button>
            </form>

            <p className="text-center text-sm text-gray-600">
              Already have an account?{" "}
              <Link href="/login" className="font-semibold text-blue-600 hover:underline">
                Log in
              </Link>
            </p>
          </div>
        </div>
      </main>

      {/* FOOTER */}
      <footer className="row-start-3 flex justify-center items-center bg-blue-800 text-white p-4 mt-8 shadow-inner">
        Informatics Engineering × Chemical Engineering 2025
      </footer>
    </div>
  );
}
